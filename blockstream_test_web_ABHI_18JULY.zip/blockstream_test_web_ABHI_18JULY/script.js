var year = new Date().getFullYear();
var month = (new Date().getMonth() > 10) ? new Date().getMonth() : "0" + new Date().getMonth();
var date = (new Date().getDate() > 10) ? new Date().getDate() : "0" + new Date().getDate();
var curr = year + "" + month + "" + date;
var url = "https://chain.api.btc.com/v3/block/date/" + curr;

let request = new XMLHttpRequest();
request.open("GET", url);
request.onreadystatechange = function() {
  if (request.readyState === XMLHttpRequest.DONE && request.status === 200) {
    var req = JSON.parse(request.responseText);
    var table = "<table class=\"table\">";
    table += "<thead><tr><th scope=\"col\">Height</th><th scope=\"col\">Hash</th><th scope=\"col\">Size(bytes)</th><th scope=\"col\">Miner</th><th scope=\"col\">Time</th></tr></thead>";
    for (i = 0; i < 10; i++) {
      var height = req.data[i].height;
      var hash = req.data[i].hash;
      var size = req.data[i].size;
      var relayed = req.data[i].extras.pool_name;
      var date = new Date(0);
      var bitcoinTime = req.data[i].timestamp;
      date.setUTCSeconds(bitcoinTime);
      var time = date;
      var hash2 = 'https://chain.api.btc.com/v3/block/' + hash;

      table += "<tr><td>" + height + "</td><td>" + '<a href="' + hash2 + '">' + hash + '</a>' + "</td><td>" + size + "</td><td>" + relayed + "</td><td>" + time + "</td></tr>";
    }
    table += "</table>";
    document.getElementById("mydiv").innerHTML = table;
  }
};
request.send();

//Function converting milliseconds to local time
function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

  hours = (hours < 10) ? "0" + hours : hours;
  minutes = (minutes < 10) ? "0" + minutes : minutes;
  seconds = (seconds < 10) ? "0" + seconds : seconds;

  return hours + ":" + minutes + ":" + seconds + "." + milliseconds;
}

// Search function
function myFunction() {
  var input, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value;
  table = document.getElementById("mydiv");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
