1) open and run index.html file
2) Recently created blocks will be displayed based on the current date
3) Search functionality happens in real-time as you type the height.